// App.js
import React from "react";
import AppNavigation from "./navigation/appNavigation";

const App = () => {
  return <AppNavigation />;
};

export default App;
