Commands for firebase Authentication
* expo install firebase
